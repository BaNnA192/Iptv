import { AppError } from "../services/errors/AppError";

export function normalizeBaseUrl(input: string): string {
  try {
    const url = new URL(input.trim());
    if (!["http:", "https:"].includes(url.protocol)) throw new Error();
    return url.origin + url.pathname.replace(/\/$/, "");
  } catch {
    throw new AppError("INVALID_URL", "Please enter a valid server URL starting with http:// or https://");
  }
}

export function validateHttpUrl(input: string): string {
  try {
    const url = new URL(input.trim());
    if (!["http:", "https:"].includes(url.protocol)) throw new Error();
    return url.toString();
  } catch {
    throw new AppError("INVALID_URL", "Please enter a valid URL starting with http:// or https://");
  }
}

export function safeText(value: unknown, fallback = ""): string {
  return String(value ?? fallback).replace(/[<>]/g, "");
}
