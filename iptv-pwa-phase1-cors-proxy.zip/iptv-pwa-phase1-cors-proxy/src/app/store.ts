import { create } from "zustand";
import { Category, ContentType, Profile, ProviderAdapter, StreamItem } from "../types/iptv";
import { storage } from "../services/storage/storage";
import { XtreamProvider } from "../services/providers/xtream";
import { M3uProvider } from "../services/providers/m3u";

interface AppState {
  profiles: Profile[];
  activeProfile?: Profile;
  provider?: ProviderAdapter;
  favorites: StreamItem[];
  recent: StreamItem[];
  boot: () => void;
  addProfile: (profile: Profile) => Promise<void>;
  setActiveProfile: (id: string) => void;
  logout: () => void;
  loadCategories: (type: ContentType) => Promise<Category[]>;
  loadStreams: (type: ContentType, categoryId?: string) => Promise<StreamItem[]>;
  toggleFavorite: (item: StreamItem) => void;
  addRecent: (item: StreamItem) => void;
}

function createProvider(profile: Profile): ProviderAdapter {
  if (profile.type === "xtream") return new XtreamProvider(profile.serverUrl!, profile.username!, profile.password!);
  return new M3uProvider(profile.m3uUrl!);
}

export const useAppStore = create<AppState>((set, get) => ({
  profiles: [],
  favorites: [],
  recent: [],
  boot: () => {
    const profiles = storage.getProfiles();
    const activeId = storage.getActiveProfileId();
    const activeProfile = profiles.find((p) => p.id === activeId) || profiles[0];
    set({
      profiles,
      favorites: storage.getFavorites(),
      recent: storage.getRecent(),
      activeProfile,
      provider: activeProfile ? createProvider(activeProfile) : undefined
    });
  },
  addProfile: async (profile) => {
    const provider = createProvider(profile);
    await provider.validate();
    const profiles = [profile, ...get().profiles.filter((p) => p.id !== profile.id)];
    storage.saveProfiles(profiles);
    storage.setActiveProfileId(profile.id);
    set({ profiles, activeProfile: profile, provider });
  },
  setActiveProfile: (id) => {
    const activeProfile = get().profiles.find((p) => p.id === id);
    if (!activeProfile) return;
    storage.setActiveProfileId(id);
    set({ activeProfile, provider: createProvider(activeProfile) });
  },
  logout: () => {
    storage.clearActiveProfileId();
    set({ activeProfile: undefined, provider: undefined });
  },
  loadCategories: async (type) => {
    const provider = get().provider;
    if (!provider) return [];
    return provider.getCategories(type);
  },
  loadStreams: async (type, categoryId) => {
    const provider = get().provider;
    if (!provider) return [];
    return provider.getStreams(type, categoryId);
  },
  toggleFavorite: (item) => {
    const exists = get().favorites.some((x) => x.id === item.id && x.name === item.name);
    const favorites = exists ? get().favorites.filter((x) => !(x.id === item.id && x.name === item.name)) : [item, ...get().favorites];
    storage.saveFavorites(favorites);
    set({ favorites });
  },
  addRecent: (item) => {
    const recent = [item, ...get().recent.filter((x) => !(x.id === item.id && x.name === item.name))].slice(0, 50);
    storage.saveRecent(recent);
    set({ recent });
  }
}));
