import { Navigate, Route, Routes } from "react-router-dom";
import { useEffect } from "react";
import { useAppStore } from "./store";
import { Layout } from "../components/Layout";
import { Login } from "../features/auth/Login";
import { Home } from "../features/home/Home";
import { Library } from "../features/library/Library";
import { Player } from "../features/player/Player";
import { SearchPage } from "../features/library/Search";
import { Favorites } from "../features/library/Favorites";
import { Settings } from "../features/settings/Settings";

function Guard({ children }: { children: JSX.Element }) {
  const activeProfile = useAppStore((s) => s.activeProfile);
  if (!activeProfile) return <Navigate to="/login" replace />;
  return children;
}

export function App() {
  const boot = useAppStore((s) => s.boot);
  useEffect(() => boot(), []);
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/player" element={<Guard><Player /></Guard>} />
      <Route element={<Guard><Layout /></Guard>}>
        <Route index element={<Home />} />
        <Route path="live" element={<Library type="live" />} />
        <Route path="movies" element={<Library type="movie" />} />
        <Route path="series" element={<Library type="series" />} />
        <Route path="search" element={<SearchPage />} />
        <Route path="favorites" element={<Favorites />} />
        <Route path="settings" element={<Settings />} />
      </Route>
    </Routes>
  );
}
