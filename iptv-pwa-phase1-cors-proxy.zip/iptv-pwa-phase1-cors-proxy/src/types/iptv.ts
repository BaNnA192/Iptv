export type ProviderType = "xtream" | "m3u";
export type ContentType = "live" | "movie" | "series";

export interface Profile {
  id: string;
  name: string;
  type: ProviderType;
  serverUrl?: string;
  username?: string;
  password?: string;
  m3uUrl?: string;
  epgUrl?: string;
  createdAt: number;
}

export interface Category {
  id: string;
  name: string;
  type: ContentType;
}

export interface StreamItem {
  id: string;
  name: string;
  type: ContentType;
  categoryId?: string;
  categoryName?: string;
  logo?: string;
  url?: string;
  containerExtension?: string;
  streamId?: string | number;
  seriesId?: string | number;
  plot?: string;
  rating?: string;
  year?: string;
  raw?: unknown;
}

export interface Episode extends StreamItem {
  season?: number;
  episode?: number;
}

export interface SeriesDetails {
  info?: Record<string, unknown>;
  episodes: Episode[];
}

export interface EpgProgram {
  channelId: string;
  title: string;
  start: string;
  stop: string;
  description?: string;
}

export interface ProviderAdapter {
  validate(): Promise<void>;
  getCategories(type: ContentType): Promise<Category[]>;
  getStreams(type: ContentType, categoryId?: string): Promise<StreamItem[]>;
  getSeriesDetails?(seriesId: string | number): Promise<SeriesDetails>;
  getEpg?(streamId?: string | number): Promise<EpgProgram[]>;
  buildStreamUrl(item: StreamItem): string;
}
