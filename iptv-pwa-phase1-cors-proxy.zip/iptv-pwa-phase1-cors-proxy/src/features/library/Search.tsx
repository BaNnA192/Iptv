import { useState } from "react";
import { useAppStore } from "../../app/store";
import { StreamItem } from "../../types/iptv";
import { Card } from "./Row";

export function SearchPage() {
  const [q, setQ] = useState("");
  const [items, setItems] = useState<StreamItem[]>([]);
  const [loading, setLoading] = useState(false);
  const { loadStreams } = useAppStore();

  async function search() {
    setLoading(true);
    const all = (await Promise.all([loadStreams("live"), loadStreams("movie"), loadStreams("series")])).flat();
    setItems(all.filter((x) => x.name.toLowerCase().includes(q.toLowerCase())));
    setLoading(false);
  }

  return (
    <div className="p-5 lg:p-8">
      <h1 className="mb-4 text-4xl font-black">Search</h1>
      <div className="mb-6 flex gap-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && search()} className="flex-1 rounded-xl border border-white/10 bg-white/5 px-4 py-3 outline-none focus:border-rose-500" placeholder="Search live, movies, series..." />
        <button onClick={search} className="rounded-xl bg-rose-600 px-5 font-bold">Search</button>
      </div>
      {loading && <div className="text-zinc-400">Searching...</div>}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6">{items.map((item) => <Card key={`${item.type}-${item.id}-${item.name}`} item={item} />)}</div>
    </div>
  );
}
