import { Link } from "react-router-dom";
import { StreamItem } from "../../types/iptv";

export function Row({ title, items }: { title: string; items: StreamItem[] }) {
  if (!items.length) return null;
  return (
    <section className="mb-8">
      <h2 className="mb-4 text-2xl font-black">{title}</h2>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6">
        {items.slice(0, 12).map((item) => <Card key={`${item.type}-${item.id}-${item.name}`} item={item} />)}
      </div>
    </section>
  );
}

export function Card({ item }: { item: StreamItem }) {
  return (
    <Link to="/player" state={{ item }} className="group overflow-hidden rounded-2xl bg-white/5 transition hover:scale-[1.03] hover:bg-white/10">
      <div className="aspect-[2/3] bg-zinc-800">
        {item.logo ? (
          <img src={item.logo} alt="" className="h-full w-full object-cover" onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }} />
        ) : (
          <div className="grid h-full place-items-center p-4 text-center text-sm text-zinc-500">{item.name}</div>
        )}
      </div>
      <div className="p-3">
        <div className="line-clamp-2 font-semibold">{item.name}</div>
        <div className="mt-1 text-xs text-zinc-500">{item.categoryName || item.type}</div>
      </div>
    </Link>
  );
}
