import { useAppStore } from "../../app/store";
import { Card } from "./Row";

export function Favorites() {
  const favorites = useAppStore((s) => s.favorites);
  return (
    <div className="p-5 lg:p-8">
      <h1 className="mb-6 text-4xl font-black">Favorites</h1>
      {!favorites.length && <div className="rounded-2xl bg-white/5 p-8 text-zinc-400">No favorites yet.</div>}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6">{favorites.map((item) => <Card key={`${item.type}-${item.id}-${item.name}`} item={item} />)}</div>
    </div>
  );
}
