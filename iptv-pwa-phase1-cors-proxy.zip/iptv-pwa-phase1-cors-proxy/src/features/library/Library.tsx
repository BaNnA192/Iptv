import { useEffect, useMemo, useState } from "react";
import { ContentType, StreamItem, Category } from "../../types/iptv";
import { useAppStore } from "../../app/store";
import { friendlyError } from "../../services/errors/AppError";
import { Card } from "./Row";

export function Library({ type }: { type: ContentType }) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [activeCat, setActiveCat] = useState<string>("");
  const [items, setItems] = useState<StreamItem[]>([]);
  const [query, setQuery] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const { loadCategories, loadStreams } = useAppStore();

  useEffect(() => {
    setLoading(true);
    setError("");
    Promise.all([loadCategories(type), loadStreams(type)])
      .then(([cats, streams]) => { setCategories(cats); setItems(streams); })
      .catch((e) => setError(friendlyError(e)))
      .finally(() => setLoading(false));
  }, [type]);

  useEffect(() => {
    if (!activeCat) return;
    setLoading(true);
    loadStreams(type, activeCat).then(setItems).catch((e) => setError(friendlyError(e))).finally(() => setLoading(false));
  }, [activeCat]);

  const filtered = useMemo(() => items.filter((x) => x.name.toLowerCase().includes(query.toLowerCase())), [items, query]);
  const title = type === "live" ? "Live TV" : type === "movie" ? "Movies" : "Series";

  return (
    <div className="p-5 lg:p-8">
      <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="text-4xl font-black">{title}</h1>
          <p className="text-zinc-400">Categories, search, and playable streams.</p>
        </div>
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search..." className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 outline-none focus:border-rose-500" />
      </div>

      <div className="mb-6 flex gap-2 overflow-x-auto pb-2">
        <button onClick={() => setActiveCat("")} className={`shrink-0 rounded-full px-4 py-2 text-sm ${!activeCat ? "bg-white text-black" : "bg-white/10"}`}>All</button>
        {categories.map((c) => (
          <button key={c.id} onClick={() => setActiveCat(c.id)} className={`shrink-0 rounded-full px-4 py-2 text-sm ${activeCat === c.id ? "bg-white text-black" : "bg-white/10"}`}>{c.name}</button>
        ))}
      </div>

      {error && <div className="rounded-2xl border border-rose-500/40 bg-rose-500/10 p-4 text-rose-200">{error}</div>}
      {loading && <Skeleton />}
      {!loading && !error && !filtered.length && <div className="rounded-2xl bg-white/5 p-8 text-zinc-400">No items found.</div>}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6">
        {filtered.map((item) => <Card key={`${item.type}-${item.id}-${item.name}`} item={item} />)}
      </div>
    </div>
  );
}

function Skeleton() {
  return <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6">{Array.from({ length: 12 }).map((_, i) => <div key={i} className="aspect-[2/3] animate-pulse rounded-2xl bg-white/10" />)}</div>;
}
