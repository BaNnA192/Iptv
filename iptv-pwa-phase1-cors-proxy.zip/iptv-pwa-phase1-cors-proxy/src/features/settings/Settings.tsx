import { useAppStore } from "../../app/store";

export function Settings() {
  const { profiles, activeProfile, setActiveProfile } = useAppStore();
  return (
    <div className="p-5 lg:p-8">
      <h1 className="mb-2 text-4xl font-black">Settings</h1>
      <p className="mb-6 text-zinc-400">Profiles and browser/PWA information.</p>
      <div className="mb-8 rounded-2xl bg-white/5 p-5">
        <h2 className="mb-4 text-xl font-bold">Profiles</h2>
        <div className="space-y-2">
          {profiles.map((p) => (
            <button key={p.id} onClick={() => setActiveProfile(p.id)} className={`block w-full rounded-xl p-4 text-left ${activeProfile?.id === p.id ? "bg-white text-black" : "bg-white/10"}`}>
              <div className="font-bold">{p.name}</div>
              <div className="text-sm opacity-70">{p.type}</div>
            </button>
          ))}
        </div>
      </div>
      <div className="rounded-2xl bg-white/5 p-5 text-sm text-zinc-300">
        <h2 className="mb-3 text-xl font-bold text-white">Important browser limitations</h2>
        <p>Some IPTV servers do not allow direct browser access because of CORS. The app is correct, but the provider server may block web requests. For production, deploy with HTTPS and use a compliant proxy you control.</p>
      </div>
    </div>
  );
}
