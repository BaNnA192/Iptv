import Hls from "hls.js";
import { useEffect, useRef, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Heart, Repeat } from "lucide-react";
import { StreamItem } from "../../types/iptv";
import { useAppStore } from "../../app/store";

function proxyStreamUrl(url: string) {
  const encoded = btoa(unescape(encodeURIComponent(url))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  return `/api/stream?url=${encoded}`;
}

export function Player() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const { state } = useLocation();
  const item = state?.item as StreamItem | undefined;
  const { provider, toggleFavorite, addRecent, favorites } = useAppStore();
  const [error, setError] = useState("");
  const [url, setUrl] = useState("");
  const [useProxyStream, setUseProxyStream] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    if (!item || !provider) return;
    addRecent(item);
    const directUrl = provider.buildStreamUrl(item);
    const streamUrl = useProxyStream ? proxyStreamUrl(directUrl) : directUrl;
    setUrl(streamUrl);
    const video = videoRef.current;
    if (!video) return;
    setError("");

    let hls: Hls | undefined;
    const isHls = streamUrl.includes(".m3u8") || streamUrl.includes("m3u8");
    if (isHls && Hls.isSupported()) {
      hls = new Hls({ enableWorker: true, lowLatencyMode: true });
      hls.loadSource(streamUrl);
      hls.attachMedia(video);
      hls.on(Hls.Events.ERROR, (_, data) => {
        if (data.fatal) setError("Stream failed. Try the proxy stream button or choose another stream.");
      });
    } else if (video.canPlayType("application/vnd.apple.mpegurl") || !isHls) {
      video.src = streamUrl;
    } else {
      setError("This stream format is not supported by your browser.");
    }

    video.play().catch(() => setError("Autoplay was blocked. Press play manually."));
    return () => { hls?.destroy(); video.removeAttribute("src"); video.load(); };
  }, [item?.id, useProxyStream, reloadKey]);

  if (!item) {
    return <div className="p-8"><Link to="/" className="text-rose-400">Go home</Link><div className="mt-4">No stream selected.</div></div>;
  }

  const isFav = favorites.some((x) => x.id === item.id && x.name === item.name);

  return (
    <div className="min-h-screen bg-black p-4 lg:p-8">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <Link to="/" className="text-sm text-rose-400">← Back</Link>
          <h1 className="mt-2 text-2xl font-black">{item.name}</h1>
          <p className="text-sm text-zinc-500">{item.categoryName || item.type}</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => { setUseProxyStream((v) => !v); setReloadKey((k) => k + 1); }} className="rounded-xl bg-white/10 px-4 py-3 text-sm font-semibold">
            {useProxyStream ? "Direct stream" : "Proxy stream"}
          </button>
          <button onClick={() => setReloadKey((k) => k + 1)} className="rounded-xl bg-white/10 px-4 py-3"><Repeat size={18} /></button>
          <button onClick={() => toggleFavorite(item)} className={`rounded-xl px-4 py-3 ${isFav ? "bg-rose-600" : "bg-white/10"}`}><Heart /></button>
        </div>
      </div>

      <div className="overflow-hidden rounded-3xl border border-white/10 bg-zinc-950">
        <video ref={videoRef} controls playsInline className="aspect-video w-full bg-black" />
      </div>

      {error && <div className="mt-4 rounded-2xl border border-yellow-500/40 bg-yellow-500/10 p-4 text-yellow-100">{error}</div>}
      <div className="mt-4 rounded-2xl bg-white/5 p-4 text-sm text-zinc-400">
        <div className="mb-2 font-semibold text-white">Streaming mode: {useProxyStream ? "Vercel proxy" : "Direct"}</div>
        <div className="break-all text-xs text-zinc-500">{url}</div>
        <p className="mt-3 text-xs text-zinc-500">Use direct first. If the browser blocks the stream, try proxy stream. Proxy streaming is for testing and may consume Vercel bandwidth.</p>
      </div>
    </div>
  );
}
