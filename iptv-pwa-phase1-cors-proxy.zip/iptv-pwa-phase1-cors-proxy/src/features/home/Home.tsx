import { Link } from "react-router-dom";
import { useAppStore } from "../../app/store";
import { Row } from "../library/Row";

export function Home() {
  const { activeProfile, recent, favorites } = useAppStore();
  return (
    <div className="p-5 lg:p-8">
      <section className="hero-bg mb-8 rounded-3xl p-8 shadow-glow">
        <div className="max-w-3xl">
          <div className="mb-3 text-sm uppercase tracking-[.35em] text-rose-300">IPTV PWA</div>
          <h1 className="mb-4 text-4xl font-black md:text-6xl">Welcome back{activeProfile ? `, ${activeProfile.name}` : ""}</h1>
          <p className="mb-6 max-w-2xl text-zinc-300">Live TV, movies, series, favorites and recent watching in a clean dark web app.</p>
          <div className="flex flex-wrap gap-3">
            <Link className="rounded-xl bg-rose-600 px-5 py-3 font-bold" to="/live">Watch Live</Link>
            <Link className="rounded-xl bg-white/10 px-5 py-3 font-bold" to="/movies">Browse Movies</Link>
          </div>
        </div>
      </section>
      <Row title="Recently watched" items={recent} />
      <Row title="Favorites" items={favorites} />
    </div>
  );
}
