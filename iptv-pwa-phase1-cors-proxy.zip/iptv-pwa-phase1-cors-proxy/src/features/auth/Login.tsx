import { FormEvent, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "../../components/Button";
import { useAppStore } from "../../app/store";
import { friendlyError } from "../../services/errors/AppError";
import { Profile, ProviderType } from "../../types/iptv";

export function Login() {
  const [type, setType] = useState<ProviderType>("xtream");
  const [name, setName] = useState("My IPTV");
  const [serverUrl, setServerUrl] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [m3uUrl, setM3uUrl] = useState("");
  const [epgUrl, setEpgUrl] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const addProfile = useAppStore((s) => s.addProfile);
  const navigate = useNavigate();

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    const profile: Profile = {
      id: crypto.randomUUID(),
      name,
      type,
      serverUrl,
      username,
      password,
      m3uUrl,
      epgUrl,
      createdAt: Date.now()
    };
    try {
      await addProfile(profile);
      navigate("/");
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="hero-bg grid min-h-screen place-items-center p-5">
      <form onSubmit={submit} className="w-full max-w-xl rounded-3xl border border-white/10 bg-black/60 p-6 shadow-2xl backdrop-blur">
        <div className="mb-6">
          <div className="mb-2 text-4xl font-black">StreamDeck IPTV</div>
          <p className="text-zinc-400">Phase 1 PWA: Xtream Codes + M3U playlist, ready for browser testing.</p>
        </div>

        <div className="mb-5 grid grid-cols-2 gap-2 rounded-2xl bg-white/5 p-2">
          <button type="button" onClick={() => setType("xtream")} className={`rounded-xl py-3 font-semibold ${type === "xtream" ? "bg-white text-black" : "text-zinc-300"}`}>Xtream Codes</button>
          <button type="button" onClick={() => setType("m3u")} className={`rounded-xl py-3 font-semibold ${type === "m3u" ? "bg-white text-black" : "text-zinc-300"}`}>M3U Playlist</button>
        </div>

        <Field label="Profile name" value={name} onChange={setName} />
        {type === "xtream" ? (
          <>
            <Field label="Server URL" placeholder="http://example.com:8080" value={serverUrl} onChange={setServerUrl} />
            <Field label="Username" value={username} onChange={setUsername} />
            <Field label="Password" type="password" value={password} onChange={setPassword} />
          </>
        ) : (
          <>
            <Field label="M3U URL" placeholder="https://example.com/playlist.m3u" value={m3uUrl} onChange={setM3uUrl} />
            <Field label="EPG URL optional" placeholder="https://example.com/epg.xml" value={epgUrl} onChange={setEpgUrl} />
          </>
        )}

        {error && <div className="mb-4 rounded-xl border border-rose-500/40 bg-rose-500/10 p-3 text-sm text-rose-200">{error}</div>}
        <Button disabled={loading} className="w-full">{loading ? "Testing connection..." : "Connect"}</Button>

        <p className="mt-4 text-xs text-zinc-500">
          Browser note: some IPTV servers block direct web requests using CORS. If this happens, use HTTPS hosting plus a legal proxy you control.
        </p>
      </form>
    </div>
  );
}

function Field({ label, value, onChange, type = "text", placeholder = "" }: { label: string; value: string; onChange: (v: string) => void; type?: string; placeholder?: string }) {
  return (
    <label className="mb-4 block">
      <span className="mb-2 block text-sm text-zinc-300">{label}</span>
      <input
        className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 outline-none transition focus:border-rose-500"
        value={value}
        type={type}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        required={label.includes("optional") ? false : true}
      />
    </label>
  );
}
