import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import { Clapperboard, Heart, Home, MonitorPlay, Search, Settings, Tv } from "lucide-react";
import { useAppStore } from "../app/store";

const nav = [
  { to: "/", label: "Home", icon: Home },
  { to: "/live", label: "Live", icon: Tv },
  { to: "/movies", label: "Movies", icon: Clapperboard },
  { to: "/series", label: "Series", icon: MonitorPlay },
  { to: "/search", label: "Search", icon: Search },
  { to: "/favorites", label: "Favorites", icon: Heart },
  { to: "/settings", label: "Settings", icon: Settings }
];

export function Layout() {
  const { activeProfile, logout } = useAppStore();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-zinc-950">
      <aside className="fixed inset-y-0 left-0 z-20 hidden w-64 border-r border-white/10 bg-black/40 p-5 backdrop-blur lg:block">
        <Link to="/" className="mb-8 flex items-center gap-3 text-xl font-black">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-rose-600 shadow-glow">▶</span>
          StreamDeck
        </Link>
        <nav className="space-y-2">
          {nav.map((n) => (
            <NavLink key={n.to} to={n.to} className={({ isActive }) =>
              `flex items-center gap-3 rounded-xl px-3 py-3 text-sm transition ${isActive ? "bg-white text-black" : "text-zinc-300 hover:bg-white/10"}`
            }>
              <n.icon size={18} /> {n.label}
            </NavLink>
          ))}
        </nav>
        <div className="absolute bottom-5 left-5 right-5 rounded-2xl bg-white/5 p-4 text-sm">
          <div className="text-zinc-400">Active profile</div>
          <div className="truncate font-semibold">{activeProfile?.name || "None"}</div>
          <button className="mt-3 text-rose-400" onClick={() => { logout(); navigate("/login"); }}>Logout</button>
        </div>
      </aside>
      <main className="lg:pl-64">
        <div className="sticky top-0 z-10 flex gap-2 overflow-x-auto border-b border-white/10 bg-zinc-950/90 p-3 backdrop-blur lg:hidden">
          {nav.map((n) => <NavLink key={n.to} to={n.to} className="rounded-full bg-white/10 px-4 py-2 text-sm">{n.label}</NavLink>)}
        </div>
        <Outlet />
      </main>
    </div>
  );
}
