import { Category, ContentType, ProviderAdapter, SeriesDetails, StreamItem } from "../../types/iptv";
import { AppError } from "../errors/AppError";
import { normalizeBaseUrl, safeText } from "../../utils/url";

export class XtreamProvider implements ProviderAdapter {
  serverUrl: string;
  username: string;
  password: string;
  useProxy: boolean;

  constructor(serverUrl: string, username: string, password: string, useProxy = true) {
    this.serverUrl = normalizeBaseUrl(serverUrl);
    this.username = username.trim();
    this.password = password.trim();
    this.useProxy = useProxy;
  }

  private api(action?: string, params: Record<string, string | number | undefined> = {}) {
    const u = new URL(this.serverUrl + "/player_api.php");
    u.searchParams.set("username", this.username);
    u.searchParams.set("password", this.password);
    if (action) u.searchParams.set("action", action);
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== "") u.searchParams.set(k, String(v));
    });
    return u.toString();
  }

  private async request<T>(action?: string, params: Record<string, string | number | undefined> = {}): Promise<T> {
    if (this.useProxy) {
      const res = await fetch("/api/xtream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          serverUrl: this.serverUrl,
          username: this.username,
          password: this.password,
          action,
          params
        })
      });

      const payload = await res.json().catch(() => null);
      if (!res.ok || !payload?.ok) {
        throw new AppError("SERVER", payload?.error || `Proxy/Xtream request failed with HTTP ${res.status}`);
      }
      if (!payload.data) throw new AppError("EMPTY_RESPONSE", "Xtream server returned an empty response.");
      return payload.data as T;
    }

    let res: Response;
    try {
      res = await fetch(this.api(action, params), { method: "GET" });
    } catch (e) {
      throw new AppError("CORS", "Cannot reach this IPTV server from the browser. This is commonly a CORS restriction.", e);
    }
    if (!res.ok) throw new AppError("SERVER", `Server returned HTTP ${res.status}`);
    const text = await res.text();
    if (!text) throw new AppError("EMPTY_RESPONSE", "Server returned an empty response.");
    try {
      return JSON.parse(text) as T;
    } catch (e) {
      throw new AppError("PARSE", "Server response is not valid JSON.", e);
    }
  }

  async validate(): Promise<void> {
    const data = await this.request<any>();
    const auth = data?.user_info?.auth;
    const status = String(data?.user_info?.status ?? "").toLowerCase();
    if (auth !== 1 && auth !== "1") throw new AppError("INVALID_CREDENTIALS", "Invalid Xtream credentials.");
    if (status && status !== "active") throw new AppError("INVALID_CREDENTIALS", `Account status is ${status}.`);
  }

  private actionForCategories(type: ContentType) {
    if (type === "live") return "get_live_categories";
    if (type === "movie") return "get_vod_categories";
    return "get_series_categories";
  }

  private actionForStreams(type: ContentType) {
    if (type === "live") return "get_live_streams";
    if (type === "movie") return "get_vod_streams";
    return "get_series";
  }

  async getCategories(type: ContentType): Promise<Category[]> {
    const rows = await this.request<any[]>(this.actionForCategories(type));
    return (Array.isArray(rows) ? rows : []).map((r) => ({
      id: String(r.category_id ?? "uncategorized"),
      name: safeText(r.category_name, "Uncategorized"),
      type
    }));
  }

  async getStreams(type: ContentType, categoryId?: string): Promise<StreamItem[]> {
    const rows = await this.request<any[]>(this.actionForStreams(type), { category_id: categoryId });
    return (Array.isArray(rows) ? rows : []).map((r) => ({
      id: String(r.stream_id ?? r.series_id ?? r.name),
      streamId: r.stream_id,
      seriesId: r.series_id,
      name: safeText(r.name, "Untitled"),
      type,
      categoryId: String(r.category_id ?? categoryId ?? ""),
      logo: r.stream_icon || r.cover || "",
      containerExtension: r.container_extension || "m3u8",
      plot: r.plot,
      rating: r.rating,
      year: r.releaseDate || r.year,
      raw: r
    }));
  }

  async getSeriesDetails(seriesId: string | number): Promise<SeriesDetails> {
    const data = await this.request<any>("get_series_info", { series_id: seriesId });
    const episodes: any[] = Object.entries(data?.episodes ?? {}).flatMap(([season, eps]) =>
      Array.isArray(eps) ? eps.map((e) => ({ ...e, season: Number(season) })) : []
    );
    return {
      info: data?.info ?? {},
      episodes: episodes.map((e) => ({
        id: String(e.id ?? e.episode_num ?? e.title),
        streamId: e.id,
        name: safeText(e.title, "Episode"),
        type: "series",
        logo: e.info?.movie_image || data?.info?.cover,
        containerExtension: e.container_extension || "mp4",
        season: e.season,
        episode: Number(e.episode_num ?? 0),
        raw: e
      }))
    };
  }

  async getEpg(streamId?: string | number) {
    const data = await this.request<any>("get_short_epg", { stream_id: streamId, limit: 20 });
    const listings = data?.epg_listings ?? [];
    return listings.map((e: any) => ({
      channelId: String(streamId ?? ""),
      title: safeText(atobSafe(e.title) || e.title || "Program"),
      start: e.start,
      stop: e.end,
      description: atobSafe(e.description) || e.description
    }));
  }

  buildStreamUrl(item: StreamItem): string {
    if (item.url) return item.url;
    if (item.type === "live") return `${this.serverUrl}/live/${this.username}/${this.password}/${item.streamId}.m3u8`;
    if (item.type === "movie") return `${this.serverUrl}/movie/${this.username}/${this.password}/${item.streamId}.${item.containerExtension || "mp4"}`;
    return `${this.serverUrl}/series/${this.username}/${this.password}/${item.streamId}.${item.containerExtension || "mp4"}`;
  }
}

function atobSafe(value: unknown) {
  try {
    if (!value) return "";
    return decodeURIComponent(escape(atob(String(value))));
  } catch {
    return "";
  }
}
