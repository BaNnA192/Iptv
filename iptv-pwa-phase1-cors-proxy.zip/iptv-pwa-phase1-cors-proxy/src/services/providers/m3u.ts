import { Category, ContentType, ProviderAdapter, StreamItem } from "../../types/iptv";
import { AppError } from "../errors/AppError";
import { safeText, validateHttpUrl } from "../../utils/url";

export class M3uProvider implements ProviderAdapter {
  m3uUrl: string;
  useProxy: boolean;
  private streams: StreamItem[] | null = null;

  constructor(m3uUrl: string, useProxy = true) {
    this.m3uUrl = validateHttpUrl(m3uUrl);
    this.useProxy = useProxy;
  }

  async validate(): Promise<void> {
    const streams = await this.load();
    if (!streams.length) throw new AppError("PARSE", "Playlist loaded but no channels were found.");
  }

  private async load(): Promise<StreamItem[]> {
    if (this.streams) return this.streams;

    let text = "";
    if (this.useProxy) {
      const res = await fetch("/api/m3u", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: this.m3uUrl })
      });
      const payload = await res.json().catch(() => null);
      if (!res.ok || !payload?.ok) {
        throw new AppError("SERVER", payload?.error || `Playlist proxy failed with HTTP ${res.status}`);
      }
      text = payload.text || "";
    } else {
      try {
        const res = await fetch(this.m3uUrl);
        if (!res.ok) throw new AppError("SERVER", `Playlist returned HTTP ${res.status}`);
        text = await res.text();
      } catch (e) {
        if (e instanceof AppError) throw e;
        throw new AppError("CORS", "Cannot load this M3U playlist from the browser. The server may block CORS.", e);
      }
    }

    this.streams = parseM3u(text);
    return this.streams;
  }

  async getCategories(type: ContentType): Promise<Category[]> {
    const streams = await this.load();
    const groups = Array.from(new Set(streams.map((s) => s.categoryName || "Uncategorized"))).sort();
    return groups.map((g) => ({ id: g, name: g, type }));
  }

  async getStreams(type: ContentType, categoryId?: string): Promise<StreamItem[]> {
    const streams = await this.load();
    return streams.filter((s) => !categoryId || s.categoryName === categoryId);
  }

  buildStreamUrl(item: StreamItem): string {
    if (!item.url) throw new AppError("STREAM_FAILED", "This playlist item has no stream URL.");
    return item.url;
  }
}

function parseAttributes(line: string): Record<string, string> {
  const attrs: Record<string, string> = {};
  const regex = /([\w-]+)="([^"]*)"/g;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(line))) attrs[match[1]] = match[2];
  return attrs;
}

export function parseM3u(text: string): StreamItem[] {
  if (!text.includes("#EXTM3U")) throw new AppError("PARSE", "This does not look like a valid M3U playlist.");
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const result: StreamItem[] = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (!line.startsWith("#EXTINF")) continue;
    const attrs = parseAttributes(line);
    const commaIndex = line.lastIndexOf(",");
    const name = safeText(commaIndex >= 0 ? line.slice(commaIndex + 1) : attrs["tvg-name"] || "Untitled");
    const url = lines[i + 1]?.startsWith("#") ? "" : lines[i + 1];
    if (!url) continue;
    const group = safeText(attrs["group-title"] || "Uncategorized");
    result.push({
      id: `${result.length}-${name}`,
      name,
      type: "live",
      categoryId: group,
      categoryName: group,
      logo: attrs["tvg-logo"],
      url,
      raw: attrs
    });
  }
  return result;
}
