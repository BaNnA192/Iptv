import { Profile, StreamItem } from "../../types/iptv";

const keys = {
  profiles: "iptv.profiles",
  activeProfile: "iptv.activeProfile",
  favorites: "iptv.favorites",
  recent: "iptv.recent"
};

export function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) as T : fallback;
  } catch {
    return fallback;
  }
}

export function writeJson<T>(key: string, value: T) {
  localStorage.setItem(key, JSON.stringify(value));
}

export const storage = {
  getProfiles: () => readJson<Profile[]>(keys.profiles, []),
  saveProfiles: (profiles: Profile[]) => writeJson(keys.profiles, profiles),
  getActiveProfileId: () => localStorage.getItem(keys.activeProfile),
  setActiveProfileId: (id: string) => localStorage.setItem(keys.activeProfile, id),
  clearActiveProfileId: () => localStorage.removeItem(keys.activeProfile),
  getFavorites: () => readJson<StreamItem[]>(keys.favorites, []),
  saveFavorites: (items: StreamItem[]) => writeJson(keys.favorites, items),
  getRecent: () => readJson<StreamItem[]>(keys.recent, []),
  saveRecent: (items: StreamItem[]) => writeJson(keys.recent, items)
};
