export type AppErrorCode =
  | "INVALID_CREDENTIALS"
  | "INVALID_URL"
  | "NETWORK"
  | "CORS"
  | "SERVER"
  | "EMPTY_RESPONSE"
  | "PARSE"
  | "UNSUPPORTED_STREAM"
  | "STREAM_FAILED"
  | "UNKNOWN";

export class AppError extends Error {
  code: AppErrorCode;
  details?: unknown;

  constructor(code: AppErrorCode, message: string, details?: unknown) {
    super(message);
    this.name = "AppError";
    this.code = code;
    this.details = details;
  }
}

export function friendlyError(error: unknown): string {
  if (error instanceof AppError) return error.message;
  if (error instanceof TypeError && String(error.message).toLowerCase().includes("fetch")) {
    return "Network or CORS error. Your IPTV server may not allow browser requests directly.";
  }
  if (error instanceof Error) return error.message;
  return "Unexpected error occurred.";
}
