# StreamDeck IPTV PWA - Phase 1 with CORS Proxy

A deploy-ready IPTV Progressive Web App for browser testing.

## What is included

- React + TypeScript + Vite
- Installable PWA
- Xtream Codes support
- M3U playlist support
- Vercel API proxy to reduce browser CORS issues
- Optional stream proxy fallback
- Live TV, Movies, Series
- Categories
- Search
- Favorites
- Recently watched
- HTML5 video player + hls.js
- Dark minimal Netflix-inspired UI

## Why this version is better

The browser does not call your IPTV server directly for login/categories/playlists.

Flow:

```text
Browser -> Vercel /api proxy -> Xtream or M3U server
```

This handles most common CORS failures for:
- Xtream authentication
- categories
- live/movie/series lists
- M3U playlist loading

For actual video playback, the player tries direct stream first.  
If it fails, use the **Proxy stream** button in the player.

## Important warning

Proxy streaming video through Vercel is useful for testing, but not ideal for production because video uses high bandwidth and serverless functions are not designed for heavy streaming.

Production recommendation:
- Use direct streaming when possible
- Use your own VPS / Railway / Cloudflare Worker / Nginx proxy for stream fallback

## Run locally

```bash
npm install
npm run dev
```

Note: Vercel API functions work best after deploying to Vercel. For full proxy testing, deploy it.

## Deploy to Vercel

1. Upload this project to GitHub.
2. Import the repo in Vercel.
3. Framework: Vite
4. Build command:

```bash
npm run build
```

5. Output directory:

```bash
dist
```

6. Deploy.

## Project structure

- `api/xtream.ts` - Xtream Codes proxy
- `api/m3u.ts` - M3U playlist proxy
- `api/stream.ts` - optional stream proxy
- `src/services/providers/xtream.ts` - frontend Xtream adapter
- `src/services/providers/m3u.ts` - frontend M3U adapter
- `src/features/player` - player with direct/proxy fallback
- `src/features/auth` - login/profile creation
- `src/app/store.ts` - app state

## Future phases

Architecture is prepared for:
- Android
- Samsung Tizen
- LG webOS

Next recommended additions:
- backend token session instead of storing credentials in browser
- EPG XMLTV full parser
- remote-control navigation mode
- parental controls
- multi-language support
- proper VPS stream proxy
