import { handleOptions, readBody, safeError, sendJson } from "./_utils";

export default async function handler(req: any, res: any) {
  if (handleOptions(req, res)) return;
  if (req.method !== "POST") return sendJson(res, 405, { ok: false, error: "Method not allowed" });

  try {
    const body = await readBody(req);
    const playlistUrl = String(body.url || "").trim();
    const url = new URL(playlistUrl);

    if (!["http:", "https:"].includes(url.protocol)) {
      return sendJson(res, 400, { ok: false, error: "Invalid playlist URL" });
    }

    const upstream = await fetch(url.toString(), {
      headers: {
        "User-Agent": "Mozilla/5.0 IPTV-PWA-Proxy",
        "Accept": "audio/x-mpegurl,application/vnd.apple.mpegurl,text/plain,*/*"
      }
    });

    const text = await upstream.text();

    return sendJson(res, upstream.ok ? 200 : upstream.status, {
      ok: upstream.ok,
      status: upstream.status,
      text
    });
  } catch (error) {
    return sendJson(res, 500, {
      ok: false,
      error: safeError(error)
    });
  }
}
