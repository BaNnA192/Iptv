import { handleOptions, safeError } from "./_utils";

export default async function handler(req: any, res: any) {
  if (handleOptions(req, res)) return;

  try {
    const target = String(req.query?.url || "");
    if (!target) {
      res.statusCode = 400;
      res.end("Missing stream URL");
      return;
    }

    const decoded = Buffer.from(target, "base64url").toString("utf8");
    const url = new URL(decoded);
    if (!["http:", "https:"].includes(url.protocol)) {
      res.statusCode = 400;
      res.end("Invalid stream URL");
      return;
    }

    const range = req.headers.range;
    const upstream = await fetch(url.toString(), {
      headers: {
        "User-Agent": "Mozilla/5.0 IPTV-PWA-Proxy",
        ...(range ? { Range: range } : {})
      }
    });

    res.statusCode = upstream.status;
    upstream.headers.forEach((value, key) => {
      const lower = key.toLowerCase();
      if (["content-type", "content-length", "content-range", "accept-ranges", "cache-control"].includes(lower)) {
        res.setHeader(key, value);
      }
    });
    res.setHeader("Access-Control-Allow-Origin", "*");

    if (!upstream.body) {
      res.end();
      return;
    }

    const reader = upstream.body.getReader();
    async function pump() {
      const { done, value } = await reader.read();
      if (done) {
        res.end();
        return;
      }
      res.write(Buffer.from(value));
      await pump();
    }
    await pump();
  } catch (error) {
    res.statusCode = 500;
    res.end(safeError(error));
  }
}
