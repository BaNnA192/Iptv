import { handleOptions, normalizeBaseUrl, readBody, safeError, sendJson } from "./_utils";

export default async function handler(req: any, res: any) {
  if (handleOptions(req, res)) return;
  if (req.method !== "POST") return sendJson(res, 405, { ok: false, error: "Method not allowed" });

  try {
    const body = await readBody(req);
    const serverUrl = normalizeBaseUrl(body.serverUrl);
    const username = String(body.username || "").trim();
    const password = String(body.password || "").trim();
    const action = body.action ? String(body.action) : "";
    const params = body.params && typeof body.params === "object" ? body.params : {};

    if (!username || !password) {
      return sendJson(res, 400, { ok: false, error: "Missing username or password" });
    }

    const url = new URL(serverUrl + "/player_api.php");
    url.searchParams.set("username", username);
    url.searchParams.set("password", password);
    if (action) url.searchParams.set("action", action);

    for (const [key, value] of Object.entries(params)) {
      if (value !== undefined && value !== null && value !== "") {
        url.searchParams.set(key, String(value));
      }
    }

    const upstream = await fetch(url.toString(), {
      method: "GET",
      headers: {
        "User-Agent": "Mozilla/5.0 IPTV-PWA-Proxy",
        "Accept": "application/json,text/plain,*/*"
      }
    });

    const text = await upstream.text();
    let data: any = text;
    try { data = JSON.parse(text); } catch {}

    return sendJson(res, upstream.ok ? 200 : upstream.status, {
      ok: upstream.ok,
      status: upstream.status,
      data
    });
  } catch (error) {
    return sendJson(res, 500, {
      ok: false,
      error: safeError(error)
    });
  }
}
